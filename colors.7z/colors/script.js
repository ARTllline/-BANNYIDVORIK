let colors = [];

function IsEmpty(element) {
    return element == null || element == undefined || element == '';
}


document.getElementById('saveBtn').addEventListener('click', (e) => {

    document.getElementById('nameError').innerHTML = document.getElementById('colorCodeError').innerHTML = '';
    let name = document.getElementById('colorName').value;
    let type = document.getElementById('colorType').value;
    let code = document.getElementById('colorCode').value;

    if(IsEmpty(name) || IsEmpty(code))
    {
        document.getElementById('nameError').innerHTML = 'Заполните все поня!';
        return;
    }

    let IsExists = false;
    name = name.trim();

    colors.forEach(element => {
        
        if(element['name'] == name.toLowerCase())
        {
            IsExists = true;
            return;
        }

    });

    if(IsExists)
    {
        document.getElementById('nameError').innerHTML = 'имя уже существует!';
        return;
    }

    let regExp = /^[a-zA-Zа-яА-я]+$/m;
    
    if(!name.match(regExp))
    {
        document.getElementById('nameError').innerHTML = 'поле должно состоять только из букв!';
        return;
    }

    let typeName = '';
    let codeMsg = '';

    if (type == 0)
    {
        // regExp = /^(\d{1,3},\s*){2}\d{1,3}$/g;
        regExp = /^([01]?\d{1,2}|2[0-4]\d|25[0-5]),\s?([01]?\d{1,2}|2[0-4]\d|25[0-5]),\s?([01]?\d{1,2}|2[0-4]\d|25[0-5])$/g;

        typeName = 'RGB';
        codeMsg = 'RBG код лолжен соответствовать шаблону [0-255], [0-255], [0-255]';
    }

    else if (type == 1)
    {
        regExp = /^([01]?\d{1,2}|2[0-4]\d|25[0-5]),\s?([01]?\d{1,2}|2[0-4]\d|25[0-5]),\s?([01]?\d{1,2}|2[0-4]\d|25[0-5]),\s?\d\.?\d?$/g;
        typeName = 'RGBA';
        codeMsg = 'RBGA код лолжен соответствовать шаблону [0-255], [0-255], [0-255], [0-1]';
    }

    else if (type == 2)
    {
        regExp = /^#[0-9a-fA-F]{6}$/g;
        typeName = 'HEX';
        codeMsg = 'HEX код лолжен соответствовать шаблону #[0-9A-Z]{6}';
    }

    if(!code.match(regExp))
    {
        document.getElementById('colorCodeError').innerHTML = codeMsg;
        return;
    }

    else
    {
        colors.push({'name': name, 'type': typeName, 'code': code})
        pushToColorPanel(colors[colors.length - 1]);
    }
});

function pushToColorPanel(color) {

    let div = document.createElement('div');
    let name = document.createElement('span');
    let type = document.createElement('span');
    let code = document.createElement('span');
    name.innerHTML = color['name'];
    type.innerHTML = color['type'];
    code.innerHTML = color['code'];
    div.appendChild(name);
    div.appendChild(type);
    div.appendChild(code);
    let colorStyle = '';

    if(color['type'] == 'RGB')
        colorStyle = `rgb(${color['code']})`;

    else if(color['type'] == 'RGBA')
        colorStyle = `rgba(${color['code']})`;

    else if(color['type'] == 'HEX')
        colorStyle = color['code'];

    div.style.borderColor = colorStyle;
    div.style.background = "DarkGray";
    document.getElementById('colorsPanel').appendChild(div);
}